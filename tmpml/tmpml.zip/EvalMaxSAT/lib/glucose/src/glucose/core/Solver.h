/***************************************************************************************[Solver.h]
 Glucose -- Copyright (c) 2009-2014, Gilles Audemard, Laurent Simon
                                CRIL - Univ. Artois, France
                                LRI  - Univ. Paris Sud, France (2009-2013)
                                Labri - Univ. Bordeaux, France

 Syrup (Glucose Parallel) -- Copyright (c) 2013-2014, Gilles Audemard, Laurent Simon
                                CRIL - Univ. Artois, France
                                Labri - Univ. Bordeaux, France

Glucose sources are based on MiniSat (see below MiniSat copyrights). Permissions and copyrights of
Glucose (sources until 2013, Glucose 3.0, single core) are exactly the same as Minisat on which it 
is based on. (see below).

Glucose-Syrup sources are based on another copyright. Permissions and copyrights for the parallel
version of Glucose-Syrup (the "Software") are granted, free of charge, to deal with the Software
without restriction, including the rights to use, copy, modify, merge, publish, distribute,
sublicence, and/or sell copies of the Software, and to permit persons to whom the Software is 
furnished to do so, subject to the following conditions:

- The above and below copyrights notices and this permission notice shall be included in all
copies or substantial portions of the Software;
- The parallel version of Glucose (all files modified since Glucose 3.0 releases, 2013) cannot
be used in any competitive event (sat competitions/evaluations) without the express permission of 
the authors (Gilles Audemard / Laurent Simon). This is also the case for any competitive event
using Glucose Parallel as an embedded SAT engine (single core or not).


--------------- Original Minisat Copyrights

Copyright (c) 2003-2006, Niklas Een, Niklas Sorensson
Copyright (c) 2007-2010, Niklas Sorensson

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 **************************************************************************************************/

#ifndef Glucose_Solver_h
#define Glucose_Solver_h

#include "glucose/mtl/Heap.h"
#include "glucose/mtl/Alg.h"
#include "glucose/utils/Options.h"
#include "glucose/core/SolverTypes.h"
#include "glucose/core/BoundedQueue.h"
#include "glucose/core/Constants.h"
#include "glucose/mtl/Clone.h"
#include "glucose/core/SolverStats.h"
#include <set>
#include <vector>
#include <memory>
#include <unordered_set>
#include <algorithm>
#include <cassert>
#include <queue>

namespace Glucose {
// Core stats 

enum CoreStats {
  sumResSeen,
  sumRes,
  sumTrail,
  nbPromoted,
  originalClausesSeen,
  sumDecisionLevels,
  nbPermanentLearnts,
  nbRemovedClauses,
  nbRemovedUnaryWatchedClauses,
  nbReducedClauses,
  nbDL2,
  nbBin,
  nbUn,
  nbReduceDB,
  rnd_decisions,
  nbstopsrestarts,
  nbstopsrestartssame,
  lastblockatrestart,
  dec_vars,
  clauses_literals,
  learnts_literals,
  max_literals,
  tot_literals,
  noDecisionConflict,
  lcmtested,
    lcmreduced,
    sumSizes
} ;

#define coreStatsSize 27
//=================================================================================================
// Solver -- the main class:

struct CycleDAGNode {
    uint32_t node;
    uint32_t order = 0;
    std::vector<CycleDAGNode*> succ;
    std::vector<CycleDAGNode*> pred;
    bool active = false;

    CycleDAGNode(size_t szin, size_t szout, uint32_t n) : node(n) {
        succ.reserve(szout);
        pred.reserve(szin);
    }

    bool check_cycle(uint32_t original, uint32_t counter, uint32_t maximum) {
        if (counter >= maximum) {
            std::cout << node << " ";
            return true;
        }
        for(auto& cs : succ) {
            if (cs->active && (cs->node == original || cs->check_cycle(original, counter + 1, maximum))) {
                std::cout << node << " ";
                return true;
            }
        }
        return false;
    }

    void propagate_removal() {
        auto old_order = order;
        order = 0;
        assert(active);
        for(auto& cs: pred) {
            if (cs->active) {
                order = std::max(order, cs->order + 1);
            }
        }

        if (old_order != order) {
            for (auto &cs: succ) {
                if (cs->active && cs->order <= old_order + 1) {
                    cs->propagate_removal();
                }
            }
        }
    }
};

// Descending
    //std::priority_queue<std::pair<uint32_t, CycleDAGNode*>, std::vector<std::pair<uint32_t, CycleDAGNode*>>, std::less<std::pair<uint32_t, CycleDAGNode*>>> q;
struct mypq :public std::priority_queue<std::pair<uint32_t, CycleDAGNode*>, std::vector<std::pair<uint32_t, CycleDAGNode*>>, std::greater<std::pair<uint32_t, CycleDAGNode*>>> {
    mypq() : std::priority_queue<std::pair<uint32_t, CycleDAGNode*>, std::vector<std::pair<uint32_t, CycleDAGNode*>>, std::greater<std::pair<uint32_t, CycleDAGNode*>>> (){

    }
    mypq(std::vector<std::pair<uint32_t, CycleDAGNode*>> c) :
            std::priority_queue<std::pair<uint32_t, CycleDAGNode*>, std::vector<std::pair<uint32_t, CycleDAGNode*>>, std::greater<std::pair<uint32_t, CycleDAGNode*>>> (
                    std::greater<std::pair<uint32_t, CycleDAGNode*>>(), c)
                    {

    }
    void clear(){
        this->c.clear();
    }
};

class CycleDAG {
public:
    // TODO: We could also create an element per vertex once and manage them, would avoid new/delete all the time
    CycleDAG(std::vector<std::set<uint32_t>> &pred, std::vector<std::set<uint32_t>> &succ)
            : is_in(pred.size()), added_succ(pred.size()), prev(pred.size()) {
        added_succ.reserve(pred.size());
        stack.reserve(pred.size());
        node_to_ptr.reserve(pred.size());
        for(auto n=0; n < pred.size(); n++)
            node_to_ptr.emplace_back(pred[n].size(), succ[n].size(), n);

        for(auto n=0; n < pred.size(); n++) {
            for(auto n2: pred[n]) {
                node_to_ptr[n].pred.push_back(&node_to_ptr[n2]);
            }
            for(auto n2: succ[n]) {
                node_to_ptr[n].succ.push_back(&node_to_ptr[n2]);
            }
        }

        std::vector<std::pair<uint32_t, CycleDAGNode*>> container;
        container.reserve(pred.size());
        q = mypq(std::move(container));
    }

    bool add(uint32_t n, vec<Lit> &cycle) {
        CycleDAGNode* new_node = &node_to_ptr[n];
        if (new_node->active)
            return false;

        //assert(!checkCycle());

        is_in[n] = true;
        new_node->order = 0;
        new_node->active = true;

        for (auto& n2: new_node->pred) {
            if (n2->active) {
                new_node->order = std::max(new_node->order, n2->order + 1);
            }
        }

        // Propagate new order
        std::fill(prev.begin(), prev.end(), 0);
        for (auto& n2: new_node->succ) {
            if (n2->active && new_node->order >= n2->order) {
                q.emplace(new_node->order + 1, n2);
            }
        }

        while (!q.empty()) {
            auto cn = q.top();
            q.pop();
            assert(cn.second->active);

            if (cn.first > cn.second->order) {
                if (cn.second->node == n) {
                    auto cnode = n;
                    while (cnode != 0) {
                        cycle.push(mkLit(static_cast<int>(cnode), true));
                        cnode = prev[cnode];
                    }
                    q.clear();
                    return true;
                }
                cn.second->order = cn.first;
                for (auto &cs: cn.second->succ) {
                    if (cs->active && cn.first >= cs->order) {
                        q.emplace(cn.first + 1, cs);
                        if (prev[cs->node] == 0)
                            prev[cs->node] = cn.second->node;
                    }
                }
            }
        }
//
//        for(auto& cn : node_to_ptr) {
//            if (cn.active) {
//                for (auto &cpred : cn.pred) {
//                    assert(!cpred->active || cpred->order < cn.order);
//                }
//            }
//        }

        //assert(!checkCycle());
        return false;
    }

    /**
     * Single remove, in case of removing several nodes at once, use the bulk overload
     */
    void remove(uint32_t n) {
        auto cref = &node_to_ptr[n];
        if (!cref->active)
            return;

        is_in[n] = false;
        cref->active = false;

        for (auto &n2: cref->succ) {
            if (n2->active && n2->order == cref->order + 1) {
                stack.emplace_back(cref->order + 1, n2);
                while (!stack.empty()) {
                    auto cn = stack.back();
                    stack.pop_back();
                    cn.second->order = 0;
                    added_succ[cn.second->node] = 0;
                    for (auto &cs: cn.second->pred) {
                        if (cs->active)
                            cn.second->order = std::max(cn.second->order, cs->order + 1);
                    }

                    if (cn.second->order != cn.first) {
                        for (auto &cs: cn.second->succ) {
                            if (cs->active && cs->order <= cn.first+1) {
                                stack.emplace_back(cs->order, cs);
                            }
                        }
                    }
                }
//                n2->propagate_removal();
            }
        }
    }

    /**
     * Bulk remove, avoids costly data structure maintenance for to be deleted nodes
     */
    void remove(std::vector<uint32_t> &nodes) {
        for (auto n: nodes) {
            node_to_ptr[n].active = false;
        }
//        for (auto n: nodes) {
//            remove(n);
//        }

        for (auto n: nodes) {
            auto &cref = node_to_ptr[n];
            for (auto &n2: cref.succ) {
                if (n2->active && cref.order + 1 == n2->order && !added_succ[n2->node]) {
                    stack.emplace_back(n2->order, n2);
                    added_succ[n2->node] = true;
                }
            }
        }

        // Process the higher numbers first, propagating them might be faster?
        //sort(stack.begin(), stack.end(), std::less<>());
        while (!stack.empty()) {
            auto cn = stack.back();
            stack.pop_back();
            added_succ[cn.second->node] = false;

            cn.second->order = 0;
            for (auto &cs: cn.second->pred) {
                if (cs->active)
                    cn.second->order = std::max(cn.second->order, cs->order + 1);
            }

            if (cn.second->order != cn.first) {
                for (auto &cs: cn.second->succ) {
                    if (cs->active) { // && cs->order == cn.first + 1) {// <= cn.second->order) { // Commented part does not work
                        stack.emplace_back(cs->order, cs);
                    }
                }
            }
        }
    }

    bool checkCycle() {
        for(auto& cr: node_to_ptr) {
            if (cr.active && cr.check_cycle(cr.node, 0, is_in.size())) {
                std::cout << std::endl;
                return true;
            }
        }

        return false;
    }

    std::vector<bool> is_in;
private:
    mypq q;
    std::vector<CycleDAGNode> node_to_ptr;
    std::vector<bool> added_succ;
    std::vector<uint32_t> prev;
    std::vector<std::pair<uint32_t, CycleDAGNode*>> stack;
};

class Solver : public Clone {

    friend class SolverConfiguration;

public:

    // Constructor/Destructor:
    //
    Solver(std::vector<Solver *> share);
    Solver(const  Solver &s);

    virtual ~Solver();

    /**
     * Clone function
     */
    virtual Clone* clone() const {
        return  new Solver(*this);
    }

    // Problem specification:
    //
    virtual Var     newVar    (bool polarity = true, bool dvar = true); // Add a new variable with parameters specifying variable mode.



    void resetActivity(Var var) {
        activity[var] = std::numeric_limits<double>::lowest();
	order_heap.update(var);
    }

    bool START_LOG = false;
    void placeInTop(Var var) {
        if(!order_heap.inHeap(var)) {
            order_heap.insert(var);
        }

        activity[var] = activity[order_heap[0]]+1;
        order_heap.update(var);
        START_LOG=true;
    }

    double getActivity(Var var) {
        return activity[var]/var_inc;
    }

    void addActivity(Var var, double nbInc) {
        varBumpActivity(var, nbInc*var_inc);
    }


    bool    addClause (const vec<Lit>& ps);                     // Add a clause to the solver.
    bool    addEmptyClause();                                   // Add the empty clause, making the solver contradictory.
    bool    addClause (Lit p);                                  // Add a unit clause to the solver.
    bool    addClause (Lit p, Lit q);                           // Add a binary clause to the solver.
    bool    addClause (Lit p, Lit q, Lit r);                    // Add a ternary clause to the solver.
    virtual bool    addClause_(      vec<Lit>& ps);                     // Add a clause to the solver without making superflous internal copy. Will
                                                                // change the passed vector 'ps'.
    // Solving:
    //
    bool    simplify     ();                        // Removes already satisfied clauses.
    bool    solve        (const vec<Lit>& assumps); // Search for a model that respects a given set of assumptions.
    lbool   solveLimited (const vec<Lit>& assumps); // Search for a model that respects a given set of assumptions (With resource constraints).
    bool    solve        ();                        // Search without assumptions.
    bool    solve        (Lit p);                   // Search for a model that respects a single assumption.
    bool    solve        (Lit p, Lit q);            // Search for a model that respects two assumptions.
    bool    solve        (Lit p, Lit q, Lit r);     // Search for a model that respects three assumptions.
    bool    okay         () const;                  // FALSE means solver is in a conflicting state


    // From pysat
    bool prop_check(const vec<Lit>& assumps, vec<Lit>& prop, int psaving)
    {
        prop.clear();

        if (!ok)
            return false;

        bool    st = true;
        int  level = decisionLevel();
        CRef confl = CRef_Undef;

        // dealing with phase saving
        int psaving_copy = phase_saving;
        phase_saving = psaving;

        // propagate each assumption at a new decision level
        for (int i = 0; st && confl == CRef_Undef && i < assumps.size(); ++i) {
            Lit p = assumps[i];

            if (value(p) == l_False)
                st = false;
            else if (value(p) != l_True) {
                newDecisionLevel ();
                uncheckedEnqueue(p);
                confl = propagate();
            }
        }

        // copying the result
        if (decisionLevel() > level) {
            for (int c = trail_lim[level]; c < trail.size(); ++c)
                prop.push(trail[c]);

            // if there is a conflict, pushing
            // the conflicting literal as well
            // here we may choose a wrong literal
            // in Glucose if the clause is binary!
            if (confl != CRef_Undef)
                prop.push(ca[confl][0]);

            // backtracking
            cancelUntil(level);
        }

        // restoring phase saving
        phase_saving = psaving_copy;
        vec<Lit> tmp;
        return st && confl == CRef_Undef;
    }

       // Convenience versions of 'toDimacs()':
    void    toDimacs     (FILE* f, const vec<Lit>& assumps);            // Write CNF to file in DIMACS-format.
    void    toDimacs     (const char *file, const vec<Lit>& assumps);
    void    toDimacs     (FILE* f, Clause& c, vec<Var>& map, Var& max);
    void    toDimacs     (const char* file);
    void    toDimacs     (const char* file, Lit p);
    void    toDimacs     (const char* file, Lit p, Lit q);
    void    toDimacs     (const char* file, Lit p, Lit q, Lit r);

    // Display clauses and literals
    void printLit(Lit l);
    void printClause(CRef c);
    void printInitialClause(CRef c);

    // Variable mode:
    //
    void    setPolarity    (Var v, bool b); // Declare which polarity the decision heuristic should use for a variable. Requires mode 'polarity_user'.
    void    setDecisionVar (Var v, bool b); // Declare if a variable should be eligible for selection in the decision heuristic.

    // Read state:
    //
    lbool   value      (Var x) const;       // The current value of a variable.
    lbool   value      (Lit p) const;       // The current value of a literal.
    lbool   modelValue (Var x) const;       // The value of a variable in the last model. The last call to solve must have been satisfiable.
    lbool   modelValue (Lit p) const;       // The value of a literal in the last model. The last call to solve must have been satisfiable.
    int     nAssigns   ()      const;       // The current number of assigned literals.
    int     nClauses   ()      const;       // The current number of original clauses.
    int     nLearnts   ()      const;       // The current number of learnt clauses.
    int     nVars      ()      const;       // The current number of variables.
    int     nFreeVars  ()      ;

    inline char valuePhase(Var v) {return polarity[v];}

    // Incremental mode
    void setIncrementalMode();
    void initNbInitialVars(int nb);
    void printIncrementalStats();
    bool isIncremental();
    // Resource contraints:
    //
    void    setConfBudget(int64_t x);
    void    setPropBudget(int64_t x);
    void    budgetOff();
    void    interrupt();          // Trigger a (potentially asynchronous) interruption of the solver.
    void    clearInterrupt();     // Clear interrupt indicator flag.

    // Memory managment:
    //
    virtual void garbageCollect();
    void    checkGarbage(double gf);
    void    checkGarbage();

    // Extra results: (read-only member variable)
    //
    vec<lbool> model;             // If problem is satisfiable, this vector contains the model (if any).
    vec<Lit>   conflict;          // If problem is unsatisfiable (possibly under assumptions),
                                  // this vector represent the final conflict clause expressed in the assumptions.

    // Mode of operation:
    //
    int       verbosity;
    int       verbEveryConflicts;
    int       showModel;

    // Constants For restarts
    double    K;
    double    R;
    double    sizeLBDQueue;
    double    sizeTrailQueue;

    // Constants for reduce DB
    int          firstReduceDB;
    int          incReduceDB;
    int          specialIncReduceDB;
    unsigned int lbLBDFrozenClause;
    bool         chanseokStrategy;
    int          coLBDBound; // Keep all learnts with lbd<=coLBDBound
    // Constant for reducing clause
    int          lbSizeMinimizingClause;
    unsigned int lbLBDMinimizingClause;
    bool useLCM; // See ijcai17 (Chu Min Li paper, related to vivif).
    bool LCMUpdateLBD; // Updates the LBD when shrinking/replacing a clause with the vivification

    // Constant for heuristic
    double    var_decay;
    double    max_var_decay;
    double    clause_decay;
    double    random_var_freq;
    double    random_seed;
    int       ccmin_mode;         // Controls conflict clause minimization (0=none, 1=basic, 2=deep).
    int       phase_saving;       // Controls the level of phase saving (0=none, 1=limited, 2=full).
    bool      rnd_pol;            // Use random polarities for branching heuristics.
    bool      rnd_init_act;       // Initialize variable activities with a small random value.
    bool      randomizeFirstDescent; // the first decisions (until first cnflict) are made randomly
                                     // Useful for syrup!

    // Constant for Memory managment
    double    garbage_frac;       // The fraction of wasted memory allowed before a garbage collection is triggered.

    // Certified UNSAT ( Thanks to Marijn Heule
    // New in 2016 : proof in DRAT format, possibility to use binary output
    FILE*               certifiedOutput;
    bool                certifiedUNSAT;
    bool                vbyte;

    void write_char (unsigned char c);
    void write_lit (int n);
    template <typename T> void addToDrat(T & lits, bool add);

    // Panic mode.
    // Save memory
    uint32_t panicModeLastRemoved, panicModeLastRemovedShared;

    bool useUnaryWatched;            // Enable unary watched literals
    bool promoteOneWatchedClause;    // One watched clauses are promotted to two watched clauses if found empty

    // Functions useful for multithread solving
    // Useless in the sequential case
    // Overide in ParallelSolver
    virtual void parallelImportClauseDuringConflictAnalysis(Clause &c,CRef confl);
    virtual bool parallelImportClauses(); // true if the empty clause was received
    virtual void parallelImportUnaryClauses();
    virtual void parallelExportUnaryClause(Lit p);
    virtual void parallelExportClauseDuringSearch(Clause &c);
    virtual bool parallelJobIsFinished();
    virtual bool panicModeIsEnabled();


    double luby(double y, int x);

    // Statistics
    vec<uint64_t> stats;

    // Important stats completely related to search. Keep here
    uint64_t solves,starts,decisions,propagations,conflicts,conflictsRestarts;

    std::vector<Solver *> share;

protected:

    long curRestart;

    // Alpha variables
    bool glureduce;
    uint32_t restart_inc;
    bool  luby_restart;
    bool adaptStrategies;
    uint32_t luby_restart_factor;
    bool randomize_on_restarts, fixed_randomize_on_restarts, newDescent;
    uint32_t randomDescentAssignments;
    bool forceUnsatOnNewDescent;
    // Helper structures:
    //
    struct VarData { CRef reason; int level; };
    static inline VarData mkVarData(CRef cr, int l){ VarData d = {cr, l}; return d; }

    struct Watcher {
        CRef cref;
        Lit  blocker;
        Watcher(CRef cr, Lit p) : cref(cr), blocker(p) {}
        bool operator==(const Watcher& w) const { return cref == w.cref; }
        bool operator!=(const Watcher& w) const { return cref != w.cref; }
/*        Watcher &operator=(Watcher w) {
            this->cref = w.cref;
            this->blocker = w.blocker;
            return *this;
        }
*/
    };

    struct WatcherDeleted
    {
        const ClauseAllocator& ca;
        WatcherDeleted(const ClauseAllocator& _ca) : ca(_ca) {}
        bool operator()(const Watcher& w) const { return ca[w.cref].mark() == 1; }
    };

    struct VarOrderLt {
        const vec<double>&  activity;
        bool operator () (Var x, Var y) const { return activity[x] > activity[y]; }
        VarOrderLt(const vec<double>&  act) : activity(act) { }
    };


    // Solver state:
    //
    int                lastIndexRed;
    bool                ok;               // If FALSE, the constraints are already unsatisfiable. No part of the solver state may be used!
    double              cla_inc;          // Amount to bump next clause with.
    vec<double>         activity;         // A heuristic measurement of the activity of a variable.
    double              var_inc;          // Amount to bump next variable with.
    OccLists<Lit, vec<Watcher>, WatcherDeleted>
                        watches;          // 'watches[lit]' is a list of constraints watching 'lit' (will go there if literal becomes true).
    OccLists<Lit, vec<Watcher>, WatcherDeleted>
                        watchesBin;          // 'watches[lit]' is a list of constraints watching 'lit' (will go there if literal becomes true).
    OccLists<Lit, vec<Watcher>, WatcherDeleted>
                        unaryWatches;       //  Unary watch scheme (clauses are seen when they become empty
    vec<CRef>           clauses;          // List of problem clauses.
    vec<CRef>           learnts;          // List of learnt clauses.
    vec<CRef>           permanentLearnts; // The list of learnts clauses kept permanently
    vec<CRef>           permanentLearntsReduced; // The list of learnts clauses kept permanently that have been reduced by LCM
    vec<CRef>           unaryWatchedClauses;  // List of imported clauses (after the purgatory) // TODO put inside ParallelSolver
    vec<CRef>           mostActiveClauses; // Used to keep most active clauses (instead of removing them)

    vec<lbool>          assigns;          // The current assignments.
    vec<char>           polarity;         // The preferred polarity of each variable.
    vec<char>           forceUNSAT;
    void                bumpForceUNSAT(Lit q); // Handles the forces

    vec<char>           decision;         // Declares if a variable is eligible for selection in the decision heuristic.
    vec<Lit>            trail;            // Assignment stack; stores all assigments made in the order they were made.
    vec<int>            nbpos;
    vec<int>            trail_lim;        // Separator indices for different decision levels in 'trail'.
    vec<VarData>        vardata;          // Stores reason and level for each variable.
    int                 qhead;            // Head of queue (as index into the trail -- no more explicit propagation queue in MiniSat).
    int                 simpDB_assigns;   // Number of top-level assignments since last execution of 'simplify()'.
    int64_t             simpDB_props;     // Remaining number of propagations that must be made before next execution of 'simplify()'.
    vec<Lit>            assumptions;      // Current set of assumptions provided to solve by the user.
    Heap<VarOrderLt>    order_heap;       // A priority queue of variables ordered with respect to the variable activity.
    double              progress_estimate;// Set by 'search()'.
    bool                remove_satisfied; // Indicates whether possibly inefficient linear scan for satisfied clauses should be performed in 'simplify'.
    vec<unsigned int>   permDiff;           // permDiff[var] contains the current conflict number... Used to count the number of  LBD


    // UPDATEVARACTIVITY trick (see competition'09 companion paper)
    vec<Lit> lastDecisionLevel;

    ClauseAllocator     ca;

    int nbclausesbeforereduce;            // To know when it is time to reduce clause database

    // Used for restart strategies
    bqueue<unsigned int> trailQueue,lbdQueue; // Bounded queues for restarts.
    float sumLBD; // used to compute the global average of LBD. Restarts...
    int sumAssumptions;
    CRef lastLearntClause;


    // Temporaries (to reduce allocation overhead). Each variable is prefixed by the method in which it is
    // used, exept 'seen' wich is used in several places.
    //
    vec<char>           seen;
    vec<Lit>            analyze_stack;
    vec<Lit>            analyze_toclear;
    vec<Lit>            add_tmp;
    unsigned int  MYFLAG;

    // Initial reduceDB strategy
    double              max_learnts;
    double              learntsize_adjust_confl;
    int                 learntsize_adjust_cnt;

    // Resource contraints:
    //
    int64_t             conflict_budget;    // -1 means no budget.
    int64_t             propagation_budget; // -1 means no budget.
    bool                asynch_interrupt;

    // Variables added for incremental mode
    int incremental; // Use incremental SAT Solver
    int nbVarsInitialFormula; // nb VAR in formula without assumptions (incremental SAT)
    double totalTime4Sat,totalTime4Unsat;
    int nbSatCalls,nbUnsatCalls;
    vec<int> assumptionPositions,initialPositions;


    // Main internal methods:
    //
    void     insertVarOrder   (Var x);                                                 // Insert a variable in the decision order priority queue.
    Lit      pickBranchLit    ();                                                      // Return the next decision variable.
    void     newDecisionLevel ();                                                      // Begins a new decision level.
    void     uncheckedEnqueue (Lit p, CRef from = CRef_Undef);                         // Enqueue a literal. Assumes value of literal is undefined.
    bool     enqueue          (Lit p, CRef from = CRef_Undef);                         // Test if fact 'p' contradicts current state, enqueue otherwise.
    CRef     propagate        ();                                                      // Perform unit propagation. Returns possibly conflicting clause.
    CRef     propagateUnaryWatches(Lit p);                                                  // Perform propagation on unary watches of p, can find only conflicts
    void     cancelUntil      (int level);                                             // Backtrack until a certain level.
    void     analyze          (CRef confl, vec<Lit>& out_learnt, vec<Lit> & selectors, int& out_btlevel,unsigned int &nblevels,unsigned int &szWithoutSelectors);    // (bt = backtrack)
    void     analyzeFinal     (Lit p, vec<Lit>& out_conflict);                         // COULD THIS BE IMPLEMENTED BY THE ORDINARIY "analyze" BY SOME REASONABLE GENERALIZATION?
    bool     litRedundant     (Lit p, uint32_t abstract_levels);                       // (helper method for 'analyze()')
    lbool    search           (int nof_conflicts);                                     // Search for a given number of conflicts.
    virtual lbool    solve_           (bool do_simp = true, bool turn_off_simp = false);                                                      // Main solve method (assumptions given in 'assumptions').
    virtual void     reduceDB         ();                                              // Reduce the set of learnt clauses.
    void     removeSatisfied  (vec<CRef>& cs);                                         // Shrink 'cs' to contain only non-satisfied clauses.
    void     rebuildOrderHeap ();

    void     adaptSolver();                                                            // Adapt solver strategies

    // Maintaining Variable/Clause activity:
    //
    void     varDecayActivity ();                      // Decay all variables with the specified factor. Implemented by increasing the 'bump' value instead.
    void     varBumpActivity  (Var v, double inc);     // Increase a variable with the current 'bump' value.
    void     varBumpActivity  (Var v);                 // Increase a variable with the current 'bump' value.
    void     claDecayActivity ();                      // Decay all clauses with the specified factor. Implemented by increasing the 'bump' value instead.
    void     claBumpActivity  (Clause& c);             // Increase a clause with the current 'bump' value.

    // Operations on clauses:
    //
    void     attachClause     (CRef cr);               // Attach a clause to watcher lists.
    void     detachClause     (CRef cr, bool strict = false); // Detach a clause to watcher lists.
    void     detachClausePurgatory(CRef cr, bool strict = false);
    void     attachClausePurgatory(CRef cr);
    void     removeClause     (CRef cr, bool inPurgatory = false);               // Detach and free a clause.
    bool     locked           (const Clause& c) const; // Returns TRUE if a clause is a reason for some implication in the current state.
    bool     satisfied        (const Clause& c) const; // Returns TRUE if a clause is satisfied in the current state.

    template <typename T> unsigned int computeLBD(const T & lits,int end=-1);
    void minimisationWithBinaryResolution(vec<Lit> &out_learnt);

    virtual void     relocAll         (ClauseAllocator& to);

    // Misc:
    //
    int      decisionLevel    ()      const; // Gives the current decisionlevel.
    uint32_t abstractLevel    (Var x) const; // Used to represent an abstraction of sets of decision levels.
    CRef     reason           (Var x) const;
    int      level            (Var x) const;
    double   progressEstimate ()      const; // DELETE THIS ?? IT'S NOT VERY USEFUL ...
    bool     withinBudget     ()      const;
    inline bool isSelector(Var v) {return (incremental && v>nbVarsInitialFormula);}

    // Static helpers:
    //

    // Returns a random float 0 <= x < 1. Seed must never be 0.
    static inline double drand(double& seed) {
        seed *= 1389796;
        int q = (int)(seed / 2147483647);
        seed -= (double)q * 2147483647;
        return seed / 2147483647; }

    // Returns a random integer 0 <= x < size. Seed must never be 0.
    static inline int irand(double& seed, int size) {
        return (int)(drand(seed) * size); }


    // simplify
    //
public:
    // DFVS stuff
    bool checkCycle(vec<Lit>&); // Implementation at the bottom
    std::vector<std::set<uint32_t>> succ;
    std::vector<std::set<uint32_t>> pred;
    std::vector<uint32_t> cycle_stack;
    std::vector<uint32_t> cycle_list;
    std::vector<int> cycle_nb_cnt;
    uint64_t cycles_found = 0;
    uint64_t cycles_adapt = 500;
    uint64_t conflicts_adapt = 100000;
    std::vector<uint32_t> cycle_pred_cnt;
    std::vector<uint32_t> cycle_succ_cnt;
    std::vector<uint32_t> cycle_pred_not;
    std::vector<uint32_t> cycle_succ_not;
    std::vector<bool> cycle_changed_decision;
    int cycle_head=0;
    uint32_t g_size = 0;
    std::unique_ptr<CycleDAG> cycleDag = nullptr;
    std::vector<uint32_t> initial_solution;

    inline void init_dfvs() {
        if (cycleDag == nullptr) {
            cycleDag = std::make_unique<CycleDAG>(pred, succ);
            cycle_stack.reserve(pred.size());
            rnd_pol = false;
//
//            if (! initial_solution.empty() && g_size > 0) {
//                for (int idx=1; idx < g_size; idx++) {
//                    setPolarity(idx, true);
//                }
//
//                for(auto idx: initial_solution) {
//                    setPolarity(static_cast<int>(idx), false);
//                    varBumpActivity(static_cast<int>(idx), 10);
//                }
//            } else if (!pred.empty()) {
//                std::vector<std::pair<int, int>> degrees;
//                degrees.reserve(pred.size());
//                std::vector<bool> added(pred.size());
//                std::vector<int> penalty(pred.size());
//
//                for (auto n = 1; n < pred.size(); n++) {
//                    int c_max = -1;
//                    int c_node = -1;
//
//                    for (auto n2 = 1; n2 < pred.size(); n2++) {
//                        if (!added[n2]) {
//                            if ((static_cast<int>(pred[n2].size() + succ[n2].size()) + penalty[n2]) > c_max) {
//                                c_max = static_cast<int>(pred[n2].size() + succ[n2].size()) + penalty[n2];
//                                c_node = n2;
//                            }
//                        }
//                    }
//                    degrees.emplace_back(c_max, c_node);
//                    for(auto n2: pred[c_node]) {
//                        penalty[n2]--;
//                    }
//                    for(auto n2: succ[c_node]) {
//                        penalty[n2]--;
//                    }
//                    added[c_node] = true;
//                    std::vector<uint32_t> result;
//                    std::set_intersection(pred[c_node].begin(), pred[c_node].end(), succ[c_node].begin(), succ[c_node].end(),
//                                          std::back_inserter(result));
//                    degrees.emplace_back(pred[c_node].size() + succ[c_node].size() + 5 * result.size(), n);
//                }
//                std::sort(degrees.begin(), degrees.end(), std::greater<>());
//                int idx = 0;
//                /*for (; idx < pred.size() / 10; idx++) {
//                    setPolarity(degrees[idx].second, false);
//                }*/
//                for (; idx < pred.size(); idx++) {
//                    setPolarity(degrees[idx].second, true);
//		            varBumpActivity(degrees[idx].second, static_cast<double>(idx));
//                }
//            }

//            stuff for the inprocessing
//            cycle_pred_cnt.resize(pred.size());
//            cycle_succ_cnt.resize(pred.size());
//            cycle_pred_not.resize(pred.size());
//            cycle_succ_not.resize(pred.size());
//            cycle_changed_decision.resize(pred.size());
//
//            for(uint32_t n=0; n < pred.size(); n++) {
//                cycle_pred_cnt[n] = pred[n].size();
//                cycle_succ_cnt[n] = succ[n].size();
//            }
        }
    }
//
//    inline bool dfvs_nb_removable(uint32_t node) {
//        return
//        (
//            cycle_pred_cnt[node] == 0
//            || cycle_succ_cnt[node] == 0
//            || (cycle_pred_cnt[node] == 1 && cycle_pred_not[node] == 0 && cycle_succ_not[node] == 0)
//            || (cycle_succ_cnt[node] == 1 && cycle_succ_not[node] == 0 && cycle_pred_not[node] == 0)
//        );
//    }
//
//    inline void dfvs_set_nb(Lit p) {
//        return;
//        if (var(p) < pred.size()) {
//            auto n = var(p);
//            for(auto n2 : pred[n]) {
//                if (sign(p)) {
//                    cycle_succ_not[n2]++;
//                    if (cycle_changed_decision[n2] && !dfvs_nb_removable(n2)) {
//                        decision[static_cast<int>(n2)] = true;
//                        cycle_changed_decision[n2] = false;
//                    }
//                } else {
//                    cycle_succ_cnt[n2]--;
//                    if (decision[static_cast<int>(n2)] && ! cycle_changed_decision[n2] && dfvs_nb_removable(n2)){
//                        decision[static_cast<int>(n2)] = false;
//                        cycle_changed_decision[n2] = true;
//                    }
//                }
//            }
//
//            for(auto n2 : succ[n]) {
//                if (sign(p)) {
//                    cycle_pred_not[n2]++;
//                    if (cycle_changed_decision[n2] && !dfvs_nb_removable(n2)) {
//                        decision[static_cast<int>(n2)] = true;
//                        cycle_changed_decision[n2] = false;
//                    }
//                } else {
//                    cycle_pred_cnt[n2]--;
//                    if (decision[static_cast<int>(n2)] && !cycle_changed_decision[n2] && dfvs_nb_removable(n2)){
//                        decision[static_cast<int>(n2)] = false;
//                        cycle_changed_decision[n2] = true;
//                    }
//                }
//            }
//        }
//    }
//
//    inline void dfvs_undo_nb(Lit p) {
//        return;
//        if (var(p) < pred.size()) {
//            auto n = var(p);
//            for(auto n2 : pred[n]) {
//                if (sign(p)) {
//                    cycle_succ_not[n2]--;
//                    if (decision[static_cast<int>(n2)] && !cycle_changed_decision[n2] && dfvs_nb_removable(n2)){
//                        decision[static_cast<int>(n2)] = false;
//                        cycle_changed_decision[n2] = true;
//                    }
//                } else {
//                    cycle_succ_cnt[n2]++;
//                    if (cycle_changed_decision[n2] && !dfvs_nb_removable(n2)) {
//                        decision[static_cast<int>(n2)] = true;
//                        cycle_changed_decision[n2] = false;
//                    }
//                }
//            }
//
//            for(auto n2 : succ[n]) {
//                if (sign(p)) {
//                    cycle_pred_not[n2]--;
//                    if (decision[static_cast<int>(n2)] && !cycle_changed_decision[n2] && dfvs_nb_removable(n2)){
//                        decision[static_cast<int>(n2)] = false;
//                        cycle_changed_decision[n2] = true;
//                    }
//                } else {
//                    cycle_pred_cnt[n2]++;
//                    if (cycle_changed_decision[n2] && !dfvs_nb_removable(n2)) {
//                        decision[static_cast<int>(n2)] = true;
//                        cycle_changed_decision[n2] = false;
//                    }
//                }
//            }
//        }
//    }
    // DFVS stuff end

    bool	simplifyAll();
    void	simplifyLearnt(Clause& c);
    int		trailRecord;
    void	litsEnqueue(int cutP, Clause& c);
    void	cancelUntilTrailRecord();
    void	simpleUncheckEnqueue(Lit p, CRef from = CRef_Undef);
    CRef    simplePropagate();
    CRef    simplePropagateUnaryWatches(Lit p);

    vec<Lit> simp_learnt_clause;
    vec<CRef> simp_reason_clause;
    void	simpleAnalyze(CRef confl, vec<Lit>& out_learnt, vec<CRef>& reason_clause, bool True_confl);
    // sort learnt clause literal by litValue

    // in redundant
    bool removed(CRef cr);
    int performLCM;

    //// test
    vec<int> valueDup;
    void compareValue();
    void wholeCompareValue();


};


//=================================================================================================
// Implementation of inline methods:

inline CRef Solver::reason(Var x) const { return vardata[x].reason; }
inline int  Solver::level (Var x) const { return vardata[x].level; }

inline void Solver::insertVarOrder(Var x) {
    if (!order_heap.inHeap(x) && decision[x]) order_heap.insert(x); }

inline void Solver::varDecayActivity() { var_inc *= (1 / var_decay); }
inline void Solver::varBumpActivity(Var v) { varBumpActivity(v, var_inc); }
inline void Solver::varBumpActivity(Var v, double inc) {
    if ( (activity[v] += inc) > 1e100 ) {
        // Rescale:
        for (int i = 0; i < nVars(); i++)
            activity[i] *= 1e-100;
        var_inc *= 1e-100; }

    // Update order_heap with respect to new activity:
    if (order_heap.inHeap(v))
        order_heap.decrease(v); }

inline void Solver::claDecayActivity() { cla_inc *= (1 / clause_decay); }
inline void Solver::claBumpActivity (Clause& c) {
        if ( (c.activity() += cla_inc) > 1e20 ) {
            // Rescale:
            for (int i = 0; i < learnts.size(); i++)
                ca[learnts[i]].activity() *= 1e-20;
            cla_inc *= 1e-20; } }

inline void Solver::checkGarbage(void){ return checkGarbage(garbage_frac); }
inline void Solver::checkGarbage(double gf){
    if (ca.wasted() > ca.size() * gf)
        garbageCollect(); }

// NOTE: enqueue does not set the ok flag! (only public methods do)
inline bool     Solver::enqueue         (Lit p, CRef from)      { return value(p) != l_Undef ? value(p) != l_False : (uncheckedEnqueue(p, from), true); }
inline bool     Solver::addClause       (const vec<Lit>& ps)    { ps.copyTo(add_tmp); return addClause_(add_tmp); }
inline bool     Solver::addEmptyClause  ()                      { add_tmp.clear(); return addClause_(add_tmp); }
inline bool     Solver::addClause       (Lit p)                 { add_tmp.clear(); add_tmp.push(p); return addClause_(add_tmp); }
inline bool     Solver::addClause       (Lit p, Lit q)          { add_tmp.clear(); add_tmp.push(p); add_tmp.push(q); return addClause_(add_tmp); }
inline bool     Solver::addClause       (Lit p, Lit q, Lit r)   { add_tmp.clear(); add_tmp.push(p); add_tmp.push(q); add_tmp.push(r); return addClause_(add_tmp); }
 inline bool     Solver::locked          (const Clause& c) const {
   if(c.size()>2)
     return value(c[0]) == l_True && reason(var(c[0])) != CRef_Undef && ca.lea(reason(var(c[0]))) == &c;
   return
     (value(c[0]) == l_True && reason(var(c[0])) != CRef_Undef && ca.lea(reason(var(c[0]))) == &c)
     ||
     (value(c[1]) == l_True && reason(var(c[1])) != CRef_Undef && ca.lea(reason(var(c[1]))) == &c);
 }
inline void     Solver::newDecisionLevel()                      { trail_lim.push(trail.size()); }

inline int      Solver::decisionLevel ()      const   { return trail_lim.size(); }
inline uint32_t Solver::abstractLevel (Var x) const   { return 1 << (level(x) & 31); }
inline lbool    Solver::value         (Var x) const   { return assigns[x]; }
inline lbool    Solver::value         (Lit p) const   { return assigns[var(p)] ^ sign(p); }
inline lbool    Solver::modelValue    (Var x) const   { return model[x]; }
inline lbool    Solver::modelValue    (Lit p) const   { return model[var(p)] ^ sign(p); }
inline int      Solver::nAssigns      ()      const   { return trail.size(); }
inline int      Solver::nClauses      ()      const   { return clauses.size(); }
inline int      Solver::nLearnts      ()      const   { return learnts.size(); }
inline int      Solver::nVars         ()      const   { return vardata.size(); }
inline int      Solver::nFreeVars     ()         {
    int a = stats[dec_vars];
    return (int)(a) - (trail_lim.size() == 0 ? trail.size() : trail_lim[0]); }
inline void     Solver::setPolarity   (Var v, bool b) { polarity[v] = b; }
inline void     Solver::setDecisionVar(Var v, bool b)
{
    if      ( b && !decision[v]) stats[dec_vars]++;
    else if (!b &&  decision[v]) stats[dec_vars]--;

    decision[v] = b;
    insertVarOrder(v);
}
inline void     Solver::setConfBudget(int64_t x){ conflict_budget    = conflicts    + x; }
inline void     Solver::setPropBudget(int64_t x){ propagation_budget = propagations + x; }
inline void     Solver::interrupt(){ asynch_interrupt = true; }
inline void     Solver::clearInterrupt(){ asynch_interrupt = false; }
inline void     Solver::budgetOff(){ conflict_budget = propagation_budget = -1; }
inline bool     Solver::withinBudget() const {
    return !asynch_interrupt &&
           (conflict_budget    < 0 || conflicts < (uint64_t)conflict_budget) &&
           (propagation_budget < 0 || propagations < (uint64_t)propagation_budget); }

// FIXME: after the introduction of asynchronous interrruptions the solve-versions that return a
// pure bool do not give a safe interface. Either interrupts must be possible to turn off here, or
// all calls to solve must return an 'lbool'. I'm not yet sure which I prefer.
inline bool     Solver::solve         ()                    { budgetOff(); assumptions.clear(); return solve_() == l_True; }
inline bool     Solver::solve         (Lit p)               { budgetOff(); assumptions.clear(); assumptions.push(p); return solve_() == l_True; }
inline bool     Solver::solve         (Lit p, Lit q)        { budgetOff(); assumptions.clear(); assumptions.push(p); assumptions.push(q); return solve_() == l_True; }
inline bool     Solver::solve         (Lit p, Lit q, Lit r) { budgetOff(); assumptions.clear(); assumptions.push(p); assumptions.push(q); assumptions.push(r); return solve_() == l_True; }
inline bool     Solver::solve         (const vec<Lit>& assumps){ budgetOff(); assumps.copyTo(assumptions); return solve_() == l_True; }
inline lbool    Solver::solveLimited  (const vec<Lit>& assumps){ assumps.copyTo(assumptions); return solve_(); }
inline bool     Solver::okay          ()      const   { return ok; }

inline void     Solver::toDimacs     (const char* file){ vec<Lit> as; toDimacs(file, as); }
inline void     Solver::toDimacs     (const char* file, Lit p){ vec<Lit> as; as.push(p); toDimacs(file, as); }
inline void     Solver::toDimacs     (const char* file, Lit p, Lit q){ vec<Lit> as; as.push(p); as.push(q); toDimacs(file, as); }
inline void     Solver::toDimacs     (const char* file, Lit p, Lit q, Lit r){ vec<Lit> as; as.push(p); as.push(q); as.push(r); toDimacs(file, as); }

inline bool Solver::checkCycle(vec<Lit>& cycle) {
    init_dfvs();

    for(int i=cycle_head; i < trail.size(); i++) {
        if (!sign(trail[i]) && var(trail[i]) < pred.size()) {
            if (! cycle_stack.empty()) {
                for(auto n: cycle_stack)
                    cycleDag->remove(n);
//                cycleDag->remove(cycle_stack);
                cycle_stack.clear();
            }
            if (cycleDag->add(var(trail[i]), cycle)) {
                cycle_head = trail.size();
                return true;
            }
        }
    }
    cycle_head = trail.size();
    return false;
    // First check that there is a new relevant decision, this could also be changed to a specific number of decisions
    // in the latter, we just have to check that we perform a real check whenever we have a SAT state
//    bool run = false;
//    for(int i=cycle_head; i < trail.size(); i++) {
//        if (!sign(trail[i]) && var(trail[i]) < pred.size()) {
//            run = true;
//            break;
//        }
//    }
//    cycle_head = trail.size();
//
//    if (! run)
//        return false;
//
//    // Now check which vertices are actually in the graph.
//    uint32_t total_count = 0;
//    std::vector<bool> found(pred.size());
//    if (cycle_nb_cnt.size() < pred.size())
//        cycle_nb_cnt.resize(pred.size());
//
//    cycle_stack.clear();
//    // TODO: So actually, we could maintain this list, remove items on resetting to level and we could skip the following loop
//    cycle_list.clear();
//    // Find vertices in graph
//    for(int i=0; i < trail.size(); i++) {
//        if (!sign(trail[i]) && var(trail[i]) < pred.size()) {
//            auto n = var(trail[i]);
//            found[n] = true;
//            total_count++;
//            cycle_nb_cnt[n] = 0;
//            cycle_list.push_back(n);
//        }
//    }
//
//    // Count neighbors
//    for(auto n: cycle_list) {
//        for (auto n2: succ[n]) {
//            if (found[n2]) {
//                cycle_nb_cnt[n]++;
//            }
//        }
//        if (cycle_nb_cnt[n] == 0)
//            cycle_stack.push_back(n);
//    }
//
//    // Propagate leaf deletions
//    for(int idx=0; idx < cycle_stack.size(); idx++) {
//        auto n = cycle_stack[idx];
//
//        total_count--;
//        found[n] = false;
//        for (auto n2: pred[n]) {
//            if (found[n2]) {
//                if (--cycle_nb_cnt[n2] == 0)
//                    cycle_stack.push_back(n2);
//
//                assert(cycle_nb_cnt[n2] >= 0);
//            }
//        }
//    }
//    assert(idx == cycle_stack.size());
//
//    // Find the cycle
//    if (total_count > 0) {
//        assert(total_count > 2);
//        for (auto mainIt=cycle_list.rbegin(); mainIt != cycle_list.rend(); ++mainIt) {
//            if (found[*mainIt]) {
//                // All the remaining vertices are part of a cycle, so this search is actually only run once
//                cycle_stack.clear();
//                std::vector<bool> visited(pred.size());
//                std::vector<bool> on_stack(pred.size());
//                cycle_stack.push_back(*mainIt);
//                visited[*mainIt] = true;
//
//                while (!cycle_stack.empty()) {
//                    auto cn = cycle_stack.back();
//                    if (on_stack[cn]) {
//                        on_stack[cn] = false;
//                        cycle_stack.pop_back();
//                    } else {
//                        on_stack[cn] = true;
//                    }
//
//                    for (auto n2: succ[cn]) {
//                        if (n2 == *mainIt) {
//                            cycle.push(mkLit(*mainIt, true));
//                            for (auto it = cycle_stack.rbegin(); *it != *mainIt; ++it) {
//                                assert(it != cycle_stack.rend());
//                                if (on_stack[*it])
//                                    cycle.push(mkLit(*it, true));
//                            }
//                            return true;
//                        }
//                        if (found[n2] && !visited[n2]) {
//                            visited[n2] = true;
//                            cycle_stack.push_back(n2);
//                        }
//                    }
//                }
//            }
//        }
//    }
//    assert(!non_leaf);
    return false;
}

/************************************************************
 * Compute LBD functions
 *************************************************************/

template <typename T>inline unsigned int Solver::computeLBD(const T &lits, int end) {
    int nblevels = 0;
    MYFLAG++;
#ifdef INCREMENTAL
    if(incremental) { // ----------------- INCREMENTAL MODE
      if(end==-1) end = lits.size();
      int nbDone = 0;
      for(int i=0;i<lits.size();i++) {
        if(nbDone>=end) break;
        if(isSelector(var(lits[i]))) continue;
        nbDone++;
        int l = level(var(lits[i]));
        if (permDiff[l] != MYFLAG) {
      permDiff[l] = MYFLAG;
      nblevels++;
        }
      }
    } else { // -------- DEFAULT MODE. NOT A LOT OF DIFFERENCES... BUT EASIER TO READ
#endif
    for(int i = 0; i < lits.size(); i++) {
        int l = level(var(lits[i]));
        if(permDiff[l] != MYFLAG) {
            permDiff[l] = MYFLAG;
            nblevels++;
        }
    }
#ifdef INCREMENTAL
    }
#endif
    return nblevels;
}



//=================================================================================================
// Debug etc:


inline void Solver::printLit(Lit l)
{
    printf("%s%d:%c", sign(l) ? "-" : "", var(l)+1, value(l) == l_True ? '1' : (value(l) == l_False ? '0' : 'X'));
}


inline void Solver::printClause(CRef cr)
{
  Clause &c = ca[cr];
    for (int i = 0; i < c.size(); i++){
        printLit(c[i]);
        printf(" ");
    }
}

inline void Solver::printInitialClause(CRef cr)
{
  Clause &c = ca[cr];
    for (int i = 0; i < c.size(); i++){
      if(!isSelector(var(c[i]))) {
	printLit(c[i]);
        printf(" ");
      }
    }
}

template <typename T>inline void Solver::addToDrat(T &lits, bool add) {
    if(vbyte) {
        if(add)
            write_char('a');
        else
            write_char('d');
        for(int i = 0; i < lits.size(); i++)
            write_lit(2 * (var(lits[i]) + 1) + sign(lits[i]));
        write_lit(0);
    }
    else {
        if(!add)
            fprintf(certifiedOutput, "d ");

        for(int i = 0; i < lits.size(); i++)
            fprintf(certifiedOutput, "%i ", (var(lits[i]) + 1) * (-2 * sign(lits[i]) + 1));
        fprintf(certifiedOutput, "0\n");
    }
}



//=================================================================================================
struct reduceDBAct_lt {
    ClauseAllocator& ca;

    reduceDBAct_lt(ClauseAllocator& ca_) : ca(ca_) {
    }

    bool operator()(CRef x, CRef y) {

        // Main criteria... Like in MiniSat we keep all binary clauses
        if (ca[x].size() > 2 && ca[y].size() == 2) return 1;

        if (ca[y].size() > 2 && ca[x].size() == 2) return 0;
        if (ca[x].size() == 2 && ca[y].size() == 2) return 0;

        return ca[x].activity() < ca[y].activity();
    }
};

struct reduceDB_lt {
    ClauseAllocator& ca;

    reduceDB_lt(ClauseAllocator& ca_) : ca(ca_) {
    }

    bool operator()(CRef x, CRef y) {

        // Main criteria... Like in MiniSat we keep all binary clauses
        if (ca[x].size() > 2 && ca[y].size() == 2) return 1;

        if (ca[y].size() > 2 && ca[x].size() == 2) return 0;
        if (ca[x].size() == 2 && ca[y].size() == 2) return 0;

        // Second one  based on literal block distance
        if (ca[x].lbd() > ca[y].lbd()) return 1;
        if (ca[x].lbd() < ca[y].lbd()) return 0;


        // Finally we can use old activity or size, we choose the last one
        return ca[x].activity() < ca[y].activity();
        //return x->size() < y->size();

        //return ca[x].size() > 2 && (ca[y].size() == 2 || ca[x].activity() < ca[y].activity()); }
    }
};


}


#endif
