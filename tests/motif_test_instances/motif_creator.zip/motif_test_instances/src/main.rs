use rand::Rng;
use rand::seq::SliceRandom;
use std::collections::HashMap;
use std::fs::File;
use std::io::Write;


fn main() {
    println!("Hello, world!");

    create_instance("low","stars",15);
    create_instance("low","edges",15);
    create_instance("med","stars",10);
    create_instance("med","edges",10);
    create_instance("high","stars",15);
    create_instance("high","edges",15);
}

fn create_component(noise_type:&str,last_id:i32, noise_its:i32) -> (i32,Vec<i32>,Vec<i32>,Vec<(i32,i32)>){
    let mut new_a:Vec<i32> = Vec::new();
    let mut new_b:Vec<i32> = Vec::new();
    let mut new_edges:Vec<(i32,i32)> = Vec::new();
    //println!("#### Creating new component ");
    //println!(".......Noise type: {}",noise_type);
    //println!("........With {} noise iterations",noise_its);

    let mut index = 0;
    let mut id = 0;
    let mut rv = 0;
    // Create lu and u
    new_a.push(last_id+1);
    let u = last_id + 2;
    new_b.push(u);
    new_edges.push((last_id+1,u));
    // Create lv
    let lv = last_id + 3;
    new_a.push(lv);
    id = lv + 1;

    if noise_type == "edges"{
        while index < noise_its {
            new_a.push(id);
            new_b.push(id+1);
            new_edges.push((id,id+1));
            id = id + 2;
            index += 1;
        }
    }
    else{
        while index < noise_its{
            new_a.push(id);
            new_a.push(id+1);
            new_a.push(id+2);
            new_b.push(id+3);
            new_edges.push((id,id+3));
            new_edges.push((id+1,id+3));
            new_edges.push((id+2,id+3));
            id = id + 4;
            index += 1;
        }
    }
    //Adds the last edges
    new_a.push(id);
    new_b.push(id+1);
    new_edges.push((lv,id+1));
    //println!("(lv,v) = {:?}",(lv,id+1));
    new_edges.push((id,id+1));
    //println!("(rv,v) = {:?}",(id,id+1));
    new_edges.push((id,u));
    //println!("(rv,u) = {:?}",(id,u));

    (id+1,new_a,new_b,new_edges)
}

fn generate_gr_file(noise_level:&str,noise:&str,a:Vec<i32>,b:Vec<i32>,edge_list:Vec<(i32,i32)>){
    //General file info
    let mut fname = noise_level.to_string();
    fname = "./test_instances/".to_owned() + &fname + "_"+ noise + "_test.gr";
    let mut data_file = File::create(fname).expect("creation failed");

    //Format header
    let mut _header = "p ocr ".to_string();
    let n0 = a.iter().count();
    let _n0 = n0.to_string();
    _header.push_str(&_n0);
    _header.push_str(" ");
    let n1 = b.iter().count();
    let _n1 = n1.to_string();
    _header.push_str(&_n1);
    _header.push_str(" ");
    let ned = edge_list.iter().count();
    let _ned = ned.to_string();
    _header.push_str(&_ned);
    _header.push_str("\n");

    data_file.write(_header.as_bytes()).expect("write failed");

    // Writing edges ....................
    // create hash map
    let mut ids = HashMap::new();
    let mut number = 1;

    for element in a{
        ids.insert(element,number);
        number += 1;
    }
    for element in b{
        ids.insert(element,number);
        number +=1;
    }
    for edge in edge_list{
        let mut _line = "".to_string();
        let x = ids.get(&edge.0).copied().unwrap_or(0);
        let _x = x.to_string();
        _line.push_str(&_x);
        _line.push_str(" ");
        let y = ids.get(&edge.1).copied().unwrap_or(0);
        let _y = y.to_string();
        _line.push_str(&_y);
        _line.push_str("\n");
        data_file.write(_line.as_bytes()).expect("write failed");
    }



}

fn create_instance(noise_level:&str,noise:&str,max_components:i32){
    // Partitions and edges declaration
    let mut a: Vec<i32> = Vec::new();
    let mut b: Vec<i32> = Vec::new();
    //let mut a_ids: Vec<i32> = Vec::new();
    //let mut b_ids:Vec<i32> = Vec::new();
    let mut edges: Vec<(i32,i32)> = Vec::new();
    let mut last_id:i32 = 0;
    let mut c:i32 = 0;

    // Random number generator
    let mut rng = rand::thread_rng();

    //Choose how many components will be created
    let n_comps = rng.gen_range(1..max_components);
    //println!("{} components will be created",n_comps);

    // Chooose how many noise iterations per component will be generated
    let mut n_its:i32;
    if noise_level == "high"{
        n_its = rng.gen_range(3..200);
    } else if noise_level == "low"{
        n_its = rng.gen_range(3..10);
    } else {
        n_its = rng.gen_range(3..50);
    }

    //Component generation
    //println!("with {} noise iterations per component",n_its);

    let mut component:(i32,Vec<i32>,Vec<i32>,Vec<(i32,i32)>);

    while c < n_comps{
        component = create_component(noise,last_id,n_its);
        //println!(" The new component is {:?}",component);
        last_id = component.0;
        a.append(&mut component.1);
        b.append(&mut component.2);
        edges.append(&mut component.3);
        c += 1;
    }
    //println!("Final graph");
    //println!("A : {:?} with nodes 1-{}",a,a.len());
    //println!("B : {:?} with nodes {} - {}",b,a.len() + 1,a.len()+b.len());
    //println!("Edges : {:?}",edges);

    //Generate .gr file
    generate_gr_file(noise_level,noise,a,b,edges);
}
